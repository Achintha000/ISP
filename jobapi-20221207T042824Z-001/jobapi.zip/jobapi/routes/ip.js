const express = require("express");
const router = express.Router();

const {
checkIp
} = require("../controllers/ip");

router.route("/").post(checkIp);

module.exports = router;

